from flask import Flask, render_template, request

app = Flask(__name__)

# Pricing per km for each class and aircraft
pricing = {
    "A320": {"Economy": 5, "Business": 10, "First": 20},
    "B737": {"Economy": 6, "Business": 12, "First": 25},
    "A380": {"Economy": 8, "Business": 15, "First": 30}
}

def calculate_revenue(econ, bus, first, dist, aircraft):
    """Calculate revenue breakdown and total (same logic as before)."""
    eco_revenue = econ * dist * pricing[aircraft]["Economy"]
    bus_revenue = bus * dist * pricing[aircraft]["Business"]
    first_revenue = first * dist * pricing[aircraft]["First"]

    base_revenue = eco_revenue + bus_revenue + first_revenue
    surcharge = 0
    discount = 0
    bonus = 0

    total_pass = econ + bus + first

    # Apply surcharge if passengers > 300
    if total_pass > 300:
        surcharge = base_revenue * 0.10
    # Apply discount if distance > 5000 km
    if dist > 5000:
        discount = (base_revenue + surcharge) * 0.05
    # Apply bonus for A380 with > 250 passengers
    if aircraft == "A380" and total_pass > 250:
        bonus = 100000

    adjusted_revenue = base_revenue + surcharge - discount + bonus
    return base_revenue, surcharge, discount, bonus, adjusted_revenue


@app.route("/", methods=["GET", "POST"])
def home():
    if request.method == "POST":
        try:
            econ = int(request.form["economy"])
            bus = int(request.form["business"])
            first = int(request.form["first"])
            dist = float(request.form["distance"])
            aircraft = request.form["aircraft"]

            if econ < 0 or bus < 0 or first < 0 or dist <= 0:
                return render_template("index.html", error="Please enter valid positive numbers.")

            base, surcharge, discount, bonus, total = calculate_revenue(econ, bus, first, dist, aircraft)

            return render_template(
                "result.html",
                economy=econ, business=bus, first=first,
                distance=dist, aircraft=aircraft,
                base_revenue=base,
                surcharge=surcharge,
                discount=discount,
                bonus=bonus,
                revenue=total
            )

        except ValueError:
            return render_template("index.html", error="Invalid input. Please enter numbers only.")

    return render_template("index.html")


if __name__ == "__main__":
    app.run(debug=True)
